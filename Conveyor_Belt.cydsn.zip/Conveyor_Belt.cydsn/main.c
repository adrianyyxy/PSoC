#include "project.h"
#include <stdio.h>
#include <stdlib.h>

uint8 wait;

CY_ISR(INT_DT){
    PWM_WriteCompare(0);
    
    //Timer_WriteCounter(0);
    //wait=Timer_ReadCounter();
    
    LED_Write(1);
    
    //while(wait<51){
    CyDelay(1000);
        wait=Timer_ReadCounter();
    //}
    
    LED_Write(0);
    PWM_WriteCompare(125);
    
    Sensor_ClearInterrupt();
}

int main(void)
{
    CyGlobalIntEnable;
    
    Timer_Start();
    PWM_Start();
    
    isr_Detection_StartEx(INT_DT);
    
    for(;;)
    {
    }
}
