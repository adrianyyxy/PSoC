/*******************************************************************************
* File Name: Detector.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_Detector_H)
#define CY_ISR_Detector_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void Detector_Start(void);
void Detector_StartEx(cyisraddress address);
void Detector_Stop(void);

CY_ISR_PROTO(Detector_Interrupt);

void Detector_SetVector(cyisraddress address);
cyisraddress Detector_GetVector(void);

void Detector_SetPriority(uint8 priority);
uint8 Detector_GetPriority(void);

void Detector_Enable(void);
uint8 Detector_GetState(void);
void Detector_Disable(void);

void Detector_SetPending(void);
void Detector_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the Detector ISR. */
#define Detector_INTC_VECTOR            ((reg32 *) Detector__INTC_VECT)

/* Address of the Detector ISR priority. */
#define Detector_INTC_PRIOR             ((reg8 *) Detector__INTC_PRIOR_REG)

/* Priority of the Detector interrupt. */
#define Detector_INTC_PRIOR_NUMBER      Detector__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable Detector interrupt. */
#define Detector_INTC_SET_EN            ((reg32 *) Detector__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the Detector interrupt. */
#define Detector_INTC_CLR_EN            ((reg32 *) Detector__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the Detector interrupt state to pending. */
#define Detector_INTC_SET_PD            ((reg32 *) Detector__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the Detector interrupt. */
#define Detector_INTC_CLR_PD            ((reg32 *) Detector__INTC_CLR_PD_REG)


#endif /* CY_ISR_Detector_H */


/* [] END OF FILE */
