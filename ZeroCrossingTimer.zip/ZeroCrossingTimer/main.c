#include "project.h"

int Voltage = 0; 

CY_ISR(Timer_Interruption_Handler) //interrupción del timer.
{
    SSR_Write(1); //activa el relay.
    CyDelayUs(250); //tiempo de activación.
    SSR_Write(0); //manda 0 al pulso.
    Timer_Stop(); //se detiene el timer.
    Timer_ReadStatusRegister(); //se sale de la interrupción.
}

CY_ISR(ZC_Interruption_Handler) //interrupción del cruce por 0.
{
    CyDelayUs(500); //tiempo antes de mandar el pulso.
    Timer_Start(); //inicializar la cuenta del timer.
    ZC_ClearInterrupt(); //salir de la interrupción.
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    ADC_Start(); //inicializar el ADC.
    ADC_StartConvert();// iniciar la conversión.
    Timer_Interruption_StartEx( Timer_Interruption_Handler);//inicializar la interrupción del timer.
    ZC_Interruption_StartEx(ZC_Interruption_Handler);//inicializar la interrupción del cruce por 0.
    
    for(;;)
    {
        Voltage = ADC_GetResult8(); // tomar una lectura de 8 bits del ADC 0-255.
        Timer_WritePeriod(Voltage); //escribir en el registro del periodo del timer de 8 bits 0-255.
    }
}
