/*******************************************************************************
* File Name: ZC.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ZC_H) /* Pins ZC_H */
#define CY_PINS_ZC_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "ZC_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 ZC__PORT == 15 && ((ZC__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    ZC_Write(uint8 value);
void    ZC_SetDriveMode(uint8 mode);
uint8   ZC_ReadDataReg(void);
uint8   ZC_Read(void);
void    ZC_SetInterruptMode(uint16 position, uint16 mode);
uint8   ZC_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the ZC_SetDriveMode() function.
     *  @{
     */
        #define ZC_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define ZC_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define ZC_DM_RES_UP          PIN_DM_RES_UP
        #define ZC_DM_RES_DWN         PIN_DM_RES_DWN
        #define ZC_DM_OD_LO           PIN_DM_OD_LO
        #define ZC_DM_OD_HI           PIN_DM_OD_HI
        #define ZC_DM_STRONG          PIN_DM_STRONG
        #define ZC_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define ZC_MASK               ZC__MASK
#define ZC_SHIFT              ZC__SHIFT
#define ZC_WIDTH              1u

/* Interrupt constants */
#if defined(ZC__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in ZC_SetInterruptMode() function.
     *  @{
     */
        #define ZC_INTR_NONE      (uint16)(0x0000u)
        #define ZC_INTR_RISING    (uint16)(0x0001u)
        #define ZC_INTR_FALLING   (uint16)(0x0002u)
        #define ZC_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define ZC_INTR_MASK      (0x01u) 
#endif /* (ZC__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define ZC_PS                     (* (reg8 *) ZC__PS)
/* Data Register */
#define ZC_DR                     (* (reg8 *) ZC__DR)
/* Port Number */
#define ZC_PRT_NUM                (* (reg8 *) ZC__PRT) 
/* Connect to Analog Globals */                                                  
#define ZC_AG                     (* (reg8 *) ZC__AG)                       
/* Analog MUX bux enable */
#define ZC_AMUX                   (* (reg8 *) ZC__AMUX) 
/* Bidirectional Enable */                                                        
#define ZC_BIE                    (* (reg8 *) ZC__BIE)
/* Bit-mask for Aliased Register Access */
#define ZC_BIT_MASK               (* (reg8 *) ZC__BIT_MASK)
/* Bypass Enable */
#define ZC_BYP                    (* (reg8 *) ZC__BYP)
/* Port wide control signals */                                                   
#define ZC_CTL                    (* (reg8 *) ZC__CTL)
/* Drive Modes */
#define ZC_DM0                    (* (reg8 *) ZC__DM0) 
#define ZC_DM1                    (* (reg8 *) ZC__DM1)
#define ZC_DM2                    (* (reg8 *) ZC__DM2) 
/* Input Buffer Disable Override */
#define ZC_INP_DIS                (* (reg8 *) ZC__INP_DIS)
/* LCD Common or Segment Drive */
#define ZC_LCD_COM_SEG            (* (reg8 *) ZC__LCD_COM_SEG)
/* Enable Segment LCD */
#define ZC_LCD_EN                 (* (reg8 *) ZC__LCD_EN)
/* Slew Rate Control */
#define ZC_SLW                    (* (reg8 *) ZC__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define ZC_PRTDSI__CAPS_SEL       (* (reg8 *) ZC__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define ZC_PRTDSI__DBL_SYNC_IN    (* (reg8 *) ZC__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define ZC_PRTDSI__OE_SEL0        (* (reg8 *) ZC__PRTDSI__OE_SEL0) 
#define ZC_PRTDSI__OE_SEL1        (* (reg8 *) ZC__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define ZC_PRTDSI__OUT_SEL0       (* (reg8 *) ZC__PRTDSI__OUT_SEL0) 
#define ZC_PRTDSI__OUT_SEL1       (* (reg8 *) ZC__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define ZC_PRTDSI__SYNC_OUT       (* (reg8 *) ZC__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(ZC__SIO_CFG)
    #define ZC_SIO_HYST_EN        (* (reg8 *) ZC__SIO_HYST_EN)
    #define ZC_SIO_REG_HIFREQ     (* (reg8 *) ZC__SIO_REG_HIFREQ)
    #define ZC_SIO_CFG            (* (reg8 *) ZC__SIO_CFG)
    #define ZC_SIO_DIFF           (* (reg8 *) ZC__SIO_DIFF)
#endif /* (ZC__SIO_CFG) */

/* Interrupt Registers */
#if defined(ZC__INTSTAT)
    #define ZC_INTSTAT            (* (reg8 *) ZC__INTSTAT)
    #define ZC_SNAP               (* (reg8 *) ZC__SNAP)
    
	#define ZC_0_INTTYPE_REG 		(* (reg8 *) ZC__0__INTTYPE)
#endif /* (ZC__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_ZC_H */


/* [] END OF FILE */
